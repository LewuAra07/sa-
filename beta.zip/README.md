# Beta Bots Soon. #beta #discord 
# [Discord](https://discord.gg/hayalet) - [Youtube](https://youtube.com/c/kaanxd)

# KURULUM

# `İlk olarak events adlı klasöre giriyoruz ve prefiximizi ayarlıyoruz`

`Sonrasında beta.js adlı klasöre giriyoruz ve client.login kısmına tokenimizi giriyoruz. ve botumuz açılıyor.. iyi kullanımlar..`

# HATA ÇÖZÜMLERİ

# `Eğer bir json hatası alıyorsanız croxydb adlı klasörü siliyorsunuz ve botu yeniden başlatıyorsunuz o hata gidecektir :)`