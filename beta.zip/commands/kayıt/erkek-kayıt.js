const Discord = require('discord.js')
const db = require('croxydb')


exports.run = async (client, message, args) => {
    if(!message.member.roles.cache.has('KAYIT YETKİLİSİ ROL İD')) return message.reply('** :x: Bu komutu kullanabilmek için gerekli yetkiye sahip değilsin!**')

  let verilecek = "erkek rol id"//ErkekRolİd
  let alınıcak = "kayıtsız rol id"//KayıtsızRolİD
  let isim = args[1]
  let yaş = args[2]
  let a = message.mentions.members.first()
  
  if (!a) return message.reply(new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription("Bir Üye Belirtmelisin!")
    );

  if (!isim || !yaş) return message.reply(new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(":x: lütfen isim ve yaş belirt!")
    );

  if  (isNaN(yaş)) return message.reply(new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(":x: yaşı lütfen rakamlarla yaz!")
    );
  
    db.add(`erkek_${message.author.id}`, 1)

 a.setNickname(`${isim} | ${yaş}`)
  a.roles.add(verilecek)
  a.roles.remove(alınıcak)
  
  message.channel.send(new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(":man: Kullanıcı Başarıyla Kayıt Oldu İyi Vakit Geçirmen Dileğiyle**")
    );

}

exports.config = {
    name: "erkek",
    aliases: []
};
