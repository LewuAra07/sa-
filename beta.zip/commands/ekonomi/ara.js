const discord = require('discord.js')
const Discord = require('discord.js')
const db = require("croxydb");
const ms = require("parse-ms");


module.exports.run = async(client, message, args) => {
    function rastgeleMiktar(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
  }
      let times = await db.fetch(`worktime4_${message.author.id}`);
  let day = 25000;
  if (times !== null && day - (Date.now() - times) > 0) {
    let time = ms(day - (Date.now() - times));
    message.channel.send(
      new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
  .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(
          `:x: Tekrar aramak için **${time.seconds}** saniye sonra tekrar dene!`
        )
    );
    return;
  }
  let moneys = rastgeleMiktar(50, 250);
    var sebep = ["yarramı aradın","kaanı aradın","melihi aradın","dj dikkati aradın","ghost devi aradın","kameraya nah çeken dayıyı aradın"]
    var sebepsonuç = sebep[Math.floor(Math.random() * sebep.length)];
    db.add(`para_${message.author.id}`, moneys)
    db.set(`worktime4_${message.author.id}`, Date.now())
    const embed = new discord.MessageEmbed()
  .setColor("#808080")
        .setTimestamp()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setFooter(client.user.username)
      
    .setDescription(`:white_check_mark: ${sebepsonuç} ve **${moneys}** para kazandı!`)
    return message.channel.send(embed)
};

exports.config = {
  name: "ara", //komutunuzun adı
  guildOnly: true, //burası kalsın
  aliases: ["ara"] //komutu farklı isimde çalıştırmak için
};
