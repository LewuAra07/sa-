const discord = require('discord.js')
const Discord = require('discord.js')
const db = require("croxydb");
const ms = require("parse-ms");


module.exports.run = async(client, message, args) => {
      function rastgeleMiktar(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
  }
  let times = await db.fetch(`worktime7_${message.author.id}`);
  let day = 25000;
  if (times !== null && day - (Date.now() - times) > 0) {
    let time = ms(day - (Date.now() - times));
    message.channel.send(
      new Discord.MessageEmbed()
                .setAuthor(
          message.author.tag,
          message.author.avatarURL({ dynamic: true })
        )
  .setColor("#808080")
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(
          `:x: Tekrar suç işlemek için **${time.seconds}** saniye sonra tekrar dene!`
        )
    );
    return;
  }
  const result = ["WINWIN", "LOOSELOOSE"];
  let awnser = result[Math.floor(Math.random() * result.length)];
  if(awnser == "LOOSELOOSE") {
    if(!db.fetch(`para_${message.author.id}`)) {
    message.channel.send(
      new Discord.MessageEmbed()
                .setAuthor(
          message.author.tag,
          message.author.avatarURL({ dynamic: true })
        )
  .setColor("#808080")
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(
               `:x: fakir piç paran yok!`

        )
    );
    return;
  } else if(db.fetch(`para_${message.author.id}`) < 1) {
    message.channel.send(
      new Discord.MessageEmbed()
                .setAuthor(
          message.author.tag,
          message.author.avatarURL({ dynamic: true })
        )
  .setColor("#808080")
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(
                `:x: fakir piç paran yok!`

        )
    );
    return;
  };
  let moneys = rastgeleMiktar(50, 250);
    var sebep = ["adam kattlettin","adam bıçakladn","adam öldürdün","adam bayıllttın"]
    var sebepsonuç = sebep[Math.floor(Math.random() * sebep.length)];
    db.add(`para_${message.author.id}`, moneys)
    db.set(`worktime7_${message.author.id}`, Date.now())
    const embed = new discord.MessageEmbed()
    .setAuthor(
      message.author.tag,
      message.author.displayAvatarURL({dynamic:true})
    )
  .setColor("#808080")
    .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
    .setDescription(`:white_check_mark: ${sebepsonuç} ve **${moneys}** para topladı!`)
    return message.channel.send(embed)
  } else {
    if(!db.fetch(`para_${message.author.id}`)) {
    message.channel.send(
      new Discord.MessageEmbed()
                .setAuthor(
          message.author.tag,
          message.author.avatarURL({ dynamic: true })
        )
  .setColor("#808080")
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(
               `:x: fakir piç paran yok!`

        )
    );
    return;
  } else if(db.fetch(`para_${message.author.id}`) < 1) {
    message.channel.send(
      new Discord.MessageEmbed()
                .setAuthor(
          message.author.tag,
          message.author.avatarURL({ dynamic: true })
        )
  .setColor("#808080")
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(
          `:x: fakir piç paran yok!`
        )
    );
    return;
  } 
  let moneys = rastgeleMiktar(50, 300);
  if(db.fetch(`para_${message.author.id}`) < moneys) {
    message.channel.send(
      new Discord.MessageEmbed()
                .setAuthor(
          message.author.tag,
          message.author.avatarURL({ dynamic: true })
        )
  .setColor("#808080")
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription(
          `:x: fakir piç paran yok!`
        )
    );
  }
    return;
    var sebep = ["bekçi tuttu","kekolar dövdü","polis yakaladı"]
    var sebepsonuç = sebep[Math.floor(Math.random() * sebep.length)];
    client.db.subtract(`para_${message.author.id}`, moneys)
    client.db.set(`worktime7_${message.author.id}`, Date.now())
    const embed = new discord.MessageEmbed()
    .setAuthor(
      message.author.tag,
      message.author.displayAvatarURL({dynamic:true})
    )
  .setColor("#808080")
    .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
    .setDescription(`:x: **${message.author.tag}**'i ${sebepsonuç} ve **${moneys}** para kaybetti!`)
    return message.channel.send(embed)
  }
};



exports.config = {
  name: "suç", //komutunuzun adı
  guildOnly: true, //burası kalsın
  aliases: ["suç-işle"] //komutu farklı isimde çalıştırmak için
};
