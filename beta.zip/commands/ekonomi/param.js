const discord = require ("discord.js");
const db = require ("croxydb");

const client = new discord.Client ()

exports.run = async (client, message, args) => {
 let para = db.fetch(`para_${message.author.id}`);
 const embed = new discord.MessageEmbed()
 .setTitle ('İşte Paran :coin:')
 .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
  .setColor("#808080")
 .setDescription (`Paran: **${para || 0}**`)
 message.channel.send (embed);
}
exports.config = {
  name: "para", //komutunuzun adı
  guildOnly: true, //burası kalsın
  aliases: ["param"] //komutu farklı isimde çalıştırmak için
};
