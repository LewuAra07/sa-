const Discord = require("discord.js");
const fs = require("fs");

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(
       new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("Bu komutu kullanmak için **ADMINSATOR** permine sahip olmalısın!")
    );

 const db = require("croxydb")

  if (args[0] === "kapat") {
    if (db.has(`sKanal_${message.guild.id}`) === true) {
      db.delete(`sKanal_${message.guild.id}`);

      if (db.has(`sayac_${message.guild.id}`) === true) {
        db.delete(`sayac_${message.guild.id}`);
        message.channel.send(  new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("Sayaç kanalı ve sayaç başarıyla kaldırıldı!")
    );
        return;
      }

           message.channel.send(  new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("sayaç kanalı kaldırıldı!")
    );
      return;
    }
    message.channel.send(  new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("sayaç kanalı ayarlanmamış :thinking: !")
    );
    return;
  }

  let channel = message.mentions.channels.first();
  let prefix = db.fetch(`prefix.${message.guild.id}`) || "-";

  if (!channel) {
    return message.channel.send(  new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("ayarlamak istediğin kanalı etiketle!")
    );
    
  }


  db.set(`sKanal_${message.guild.id}`, channel.id);

  const embed =   new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription(":white_check_mark: sayaç kanalı başarıyla ayarlandı! \n\n  kapatmak isterseniz `-sayaç-kanal kapat` ")
   
  message.channel.send(embed);
};

exports.config = {
    name: "sayaç-kanal",
    aliases: ["sayaç-kanal"]
};