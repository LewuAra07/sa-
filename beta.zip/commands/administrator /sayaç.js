const Discord = require("discord.js");
const fs = require("fs");

exports.run = async (client, message, args) => {
  const db = require("croxydb");

   let prefix = db.fetch(`prefix.${message.guild.id}`) || "-";
    if (!message.member.hasPermission("MANAGE_GUİLD")) 
    return message.channel.send(
      new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("Bu komutu kullanmak için **Sunucuyu Yönet** permine sahip olmalısın!")
    );
  
  if (args[0] === "kapat") {
    if (db.has(`sayac_${message.guild.id}`) === true) {
      db.delete(`sayac_${message.guild.id}`);

      if (db.has(`sKanal_${message.guild.id}`) === true) {
        db.delete(`sKanal_${message.guild.id}`);
        message.channel.send(new Discord.MessageEmbed() .setColor("#808080")
  .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription(":white_check_mark: sayaç ve sayaç kanalı başarıyla kapatıldı!"));        return;
      }

      message.channel.send(  new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("sayaç kaldırıldı!")
    );
  
      return;
    }
    message.channel.send(  new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("sayaç ayarlanmamış qardaş!")
    );
  
    return;
  }

  if (isNaN(args[0])) {
    return message.channel.send( new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("sadece sayı girmelisin!")
    );
  
  }

  if (args[0] <= message.guild.memberCount) {
    const embed = new Discord.MessageEmbed();
    return message.channel.send(  new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("Lütfen sunucu sayısından daha yüksek bir değer gir!")
    );
  
  }

  db.set(`sayac_${message.guild.id}`, args[0]);

  const embed = new Discord.MessageEmbed()
       .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
    .setDescription(`
Sayaç başarıyla ayarlandı: **${args[0]}**
Sayaç kapatmak isterseniz **${prefix}sayaç kapat** yazmanız yeterlidir.
Sayaç kanalı için **${prefix}sayaç-kanal #kanal**
`)
    .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
  .setColor("#808080");
  message.channel.send(embed);
};

exports.config = {
  name: "sayaç", //komutunuzun adı
  guildOnly: true, //burası kalsın
  aliases: ["sayaçç"] //komutu farklı isimde çalıştırmak için
};
