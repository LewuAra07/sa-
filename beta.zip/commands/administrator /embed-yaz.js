const Discord = require('discord.js')
exports.run = async (client, message, args) => {
  if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(
       new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setDescription("Bu komutu kullanmak için **ADMINSATOR** permine sahip olmalısın!")
    );

  let yazıİçeriği = args.slice().join(' ')
  const Mesaj = new Discord.MessageEmbed()
        .setColor("#808080")
    .setDescription(yazıİçeriği)

message.channel.send(Mesaj)
  
  message.delete()
}

exports.config = {
    name: "embed-yaz",
    aliases: ["embed-yaz"]
};