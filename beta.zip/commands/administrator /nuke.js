const Discord = require("discord.js");


module.exports.run = (client, message, args) => {
  if (!message.member.hasPermission("MANAGE_GUILD"))
    return message.channel.send(
      new Discord.MessageEmbed()
        .setColor("#808080")
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        ).setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true})).setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp").setTimestamp()
        .setDescription(":x: Bu komutu kullanabilmek için **Sunucuyu Yönet** yetkisine ihtiyacın var!")
    );
  message.channel.clone().then(knl => {
    let position = message.channel.position;
    knl.setPosition(position);
    message.channel.delete();
    knl.send(`:boom: Kanal bombalandı.\nhttps://imgur.com/LIyGeCR`)
  });
};

exports.config = {
    name: "nuke",
    aliases: ["bomba"]
};