const Discord = require("discord.js");
const db = require("croxydb")

exports.run = async (client, message, args) => {
  
    if (!message.member.hasPermission("BAN_MEMBERS")) 
    return message.channel.send(
      new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("Bu komutu kullanmak için **Üyeleri Yasakla** permine sahip olmalısın!")
    );
  
   let prefix = "-";
      let banned = message.mentions.users.first() || client.users.resolve(args[0]);
    let reason = args.slice(1).join(" ");
  
  if (!banned) {
      let baninfoembed = new Discord.MessageEmbed()
      .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription(`:x: yasaklamak için etiket atmayı düşünmüyormusun?`);
      message.channel.send(baninfoembed);
    
    return;
    
  };
      if (message.author === banned) {
      let sanctionyourselfembed = new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("dalgamı geçiyorsun? kendini yasaklayamazssın! :angry: ")
      message.channel.send(sanctionyourselfembed);
  
      return;
    }
    let user = message.author;
  this.user = user;
  message.guild.members.ban(banned, { reason: reason }).then((mse) => {
    message.channel.send(new Discord.MessageEmbed().setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
    .setDescription(`:white_check_mark: **${banned.tag}** sunucudan banlandı, sebep: **${reason || "Sebep belirtilmedi!"}**`))
  }).catch(error =>{ return message.channel.send(
      new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("> :x: Bu kullanıcıyı sunucudan yasaklayamıyorum!")
    ); 
    });;
  
};
  
exports.config = {
    name: "ban",
    aliases: ["yasakla"]
};