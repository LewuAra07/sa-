const Discord = require("discord.js");
const db = require("croxydb")

exports.run = async (client, message, args) => {
  
    if (!message.member.hasPermission("KICK_MEMBERS")) 
    return message.channel.send(
      new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("Bu komutu kullanmak için **Üyeleri At** permine sahip olmalısın!")
    );
  
   let prefix = "-";
      let banned = message.mentions.users.first() || client.users.resolve(args[0]);
    let reason = args.slice(1).join(" ");
  
  if (!banned) {
      let baninfoembed = new Discord.MessageEmbed()
      .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription(`:x: atmak için etiket atmayı düşünmüyormusun?`);
      message.channel.send(baninfoembed);
    
    return;
    
  };
      if (message.author === banned) {
      let sanctionyourselfembed = new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("dalgamı geçiyorsun? kendini atamazssın! :angry: ")
      message.channel.send(sanctionyourselfembed);
  
      return;
    }
let user = message.mentions.users.first()
message.guild.members.cache.get(user.id).kick(banned, { reason: reason }).then((mse) => {
    message.channel.send(new Discord.MessageEmbed().setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
    .setDescription(`:white_check_mark: **${banned.tag}** sunucudan atıldı, sebep: **${reason || "Sebep belirtilmedi!"}**`))
  }).catch(error =>{ return message.channel.send(
      new Discord.MessageEmbed()
        .setAuthor(
          message.author.tag,
          message.author.displayAvatarURL({dynamic:true})
        )
        .setColor("#808080")
        .setTimestamp()
        .setFooter(client.user.username, client.user.displayAvatarURL({dynamic:true}))
        .setThumbnail("https://images-ext-1.discordapp.net/external/ig3qrtKRJgFBQKgTqFFtbA1HFaH_njXfogwwvhWGXEY/https/cdn.discordapp.com/avatars/845990754005286934/f406dbe4ff8c438cef1b687269d8afcc.webp")
        .setDescription("> :x: Bu kullanıcıyı sunucudan atamıyorum!")
    ); 
    });;
  
};
  
exports.config = {
    name: "kick",
    aliases: ["at"]
};