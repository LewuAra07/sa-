const Discord = require("discord.js");

exports.run = async (client, message, args) => {
  let davet = `https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=8`;
  this.davet = davet;
  let discord = new Discord.MessageEmbed()
  .setAuthor(message.author.username, message.author.displayAvatarURL({dynamic:true}))
  .addField(":boom: Davet Link:", `[Tıkla!](${this.davet})`, true)
          .setFooter(
      client.user.displayAvatarURL({ dynamic: true })
    )
    .setColor("#808080")
    message.channel.send(discord)
};

  
exports.config = {
    name: "davet",
    aliases: ["invite"]
};