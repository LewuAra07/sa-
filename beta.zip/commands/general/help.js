exports.run = async (client, message, args) => {
  let embed1 = new (require('discord.js')).MessageEmbed()
  .setTitle(":writing_hand: General Commands")
  .setDescription('`-avatar`: kullanıcı avatarını gösterir. \n `-davet`: botun davet linkini gösterir. \n `-say`: sunucudaki üye sayısını görürsün. \n `-sb`: sunucu bilgilerini görürsün.')
  .setColor('#808080')
  .setAuthor(message.author.username, message.author.displayAvatarURL({dynamic:true}))
  .setTimestamp()

  let embed2 = new (require('discord.js')).MessageEmbed()
  .setTitle(":mechanical_arm:   Manage Commands")
  .setDescription('`-sayaç`: sayaç ayarlarsın gerekli bilgileri görürsün.\n `-ban`: sunucudan üye yasaklarsın. \n `-kick`: sunucudan üye atarsın. \n `-nuke`: kanalı bombalarsın. \n `-sil` belirttiğin kadar mesaj silersin. \n `-duyuru`: duyuru yaparsın. \n `-slow-mode`: yavaş mod ayarlarsın. \n `-embed-yaz`: embed yazarsın.')
  .setColor('#808080')
  .setAuthor(message.author.username, message.author.displayAvatarURL({dynamic:true}))
  .setTimestamp()

    let embed4 = new (require('discord.js')).MessageEmbed()
  .setTitle(":cherry_blossom:   Fun Commands")
  .setDescription('`-balık-tut`: balık tutarsın. \n `-kaç-cm`: kaç-cm olduğunu görürüsn(ironi). \n `-kartopu`: kartopu atarsın. \n `-koş` vartolii saadettin koşar. \n `-söv`: belirttiğin kişiye söversin(ağır). \n `-çark`: çark çevirirsin.')
  .setColor('#808080')
  .setAuthor(message.author.username, message.author.displayAvatarURL({dynamic:true}))
  .setTimestamp()

    let embed5 = new (require('discord.js')).MessageEmbed()
  .setTitle(":coin:   Economy Commands")
  .setDescription('`-param`: parana bakarsın. \n `-ara`: arayıp kazanırsın. \n `-çalış`: çalışıp kazanırsın. \n `-suç`: suç işleyip kazanırsın')
  .setColor('#808080')
  .setAuthor(message.author.username, message.author.displayAvatarURL({dynamic:true}))
  .setTimestamp()

      let embed6 = new (require('discord.js')).MessageEmbed()
  .setTitle(":hatched_chick:   Gif Commands")
  .setDescription('`-man-gif`: erkek giflerini görürsün. \n `-woman-gif`:  kadın giflerini görürsün. \n `-animal-gif`: hayvan giflerini görürsün.')
  .setColor('#808080')
  .setAuthor(message.author.username, message.author.displayAvatarURL({dynamic:true}))
  .setTimestamp()


      let embed7 = new (require('discord.js')).MessageEmbed()
  .setTitle(":underage:   Nsfw Commands")
  .setDescription('`-anal`: açıklama yok. \n `-ass`:  açıklama yok. \n `-4k`: açıklama yok.')
  .setColor('#808080')
  .setAuthor(message.author.username, message.author.displayAvatarURL({dynamic:true}))
  .setTimestamp()


  message.channel.createSlider(message.author.id, [embed1, embed2, embed4, embed5, embed6, embed7], "➡", "⬅")
};

exports.config = {
  name: "help",
  aliases: []
};