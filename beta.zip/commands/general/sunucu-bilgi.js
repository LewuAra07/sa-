const Discord = require("discord.js");

exports.run = async (client, message, args) => {
	function checkDays(date) {
            let now = new Date();
            let diff = now.getTime() - date.getTime();
            let days = Math.floor(diff / 86400000);
            return days + (days == 1 ? " gün" : " gün") + " önce";
        };
	let serverSize = message.guild.memberCount;
	let sunucusahip = message.guild.owner;
	        let botCount = message.guild.members.cache.filter(m => m.user.bot).size;
        let humanCount = serverSize - botCount;
        let verifLevels = ["Yok", "Düşük hesapta e-posta doğrulanmış olmalıdır", "Orta - Discord'a 5 dakikadan daha uzun süre kayıtlı olmalıdır", "Yüksek - (╯ ° □ °） ╯︵ ┻━┻ - sunucunun üyesi 10 dakikadan uzun olmalıdır", "Çok Yüksek - ┻━┻ ミ ヽ (ಠ 益 ಠ) ﾉ 彡 ┻━┻ - doğrulanmış bir telefon numarasına sahip olmalıdır"];
	let region = {
			"us-central": "Amerika :flag_us:",
			"us-east": "Doğu Amerika :flag_us:",
			"us-south": "Güney Amerika :flag_us:",
			"us-west": "Batı Amerika :flag_us:",
			"eu-west": "Batı Avrupa :flag_eu:",
			"eu-central": "Avrupa :flag_eu:",
			"singapore": "Singapur :flag_sg:",
			"london": "Londra :flag_gb:",
			"japan": "Japonya :flag_jp:",
			"russia": "Rusya :flag_ru:",
			"hongkong": "Hong Kong :flag_hk:",
			"brazil": "Brezilya :flag_br:",
			"singapore": "Singapur :flag_sg:",
			"sydney": "Sidney :flag_au:",
			"southafrica": "Güney Afrika :flag_za:",
    "amsterdam": "Hollanda :flag_nl:",
				"europe": "Avrupa :flag_eu:"

	}
	
	let discord = new Discord.MessageEmbed()
	.setAuthor(`${message.guild.name} - Bilgiler`, message.guild.iconURL({dynamic:true}))
  .setColor('#808080')
	.addField(':boom: Sunucu Bilgileri', `:black_medium_small_square: Sunucu İsmi: **${message.guild.name}** \n:black_medium_small_square: Sunucu ID: **${message.guild.id}**  \n:black_medium_small_square: Bulunduğu Bölge: **${region[message.guild.region]}** \n:black_medium_small_square: Kuruluş Tarihi: **${checkDays(message.guild.createdAt)}** 
`)
.addField(`:boom: Üye Bilgileri `, `:black_medium_small_square: Toplam Üye: **${humanCount}** \n:black_medium_small_square: Toplam Bot: **${botCount}** \n:black_medium_small_square: Rol Sayısı: **${message.guild.roles.cache.size}**`)
.addField(`
:boom: Kanallar`, ` :black_medium_small_square: Yazı: **${message.guild.channels.cache.filter(c => c.type === 'text').size}** \n :black_medium_small_square:  Sesli: **${message.guild.channels.cache.filter(c => c.type === 'voice').size}** \n :black_medium_small_square: Kategori: **${message.guild.channels.cache.filter(c => c.type === 'category').size}**`)

.setFooter(`${client.user.username}`, client.user.displayAvatarURL({dynamic:true}))
message.channel.send(discord)
}

exports.config = {
    name: "sb",
    aliases: ["sunucu-bilgi"]
};