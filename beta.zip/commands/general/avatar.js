const Discord = require("discord.js");
const { MessageButton } = require('discord-buttons');

exports.run = async (client, message, args) => {
  let user = message.mentions.users.first() || message.author;
    this.user = user;
  let embed = new Discord.MessageEmbed()
  .setImage(user.displayAvatarURL({dynamic:true}))
  .addField(":yum: **"+user.tag+"** adlı kullanıcının avatarı:", "_ _")
  .setColor("#808080")
  const button = new MessageButton()
  .setLabel('URL')
  .setStyle('url')
  .setEmoji('851778793832316959')
  .setURL(message.author.displayAvatarURL({ dynamic: true, size: 4096, format: 'png' }));

  return message.channel.send({ embed: embed, component: button });

};


  
exports.config = {
    name: "avatar",
    aliases: ["pp"]
};