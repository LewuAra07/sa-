const Discord = require('discord.js');

exports.run = async (client, message, args) => { 
    message.channel.send(new Discord.MessageEmbed()
        .setColor('#808080')
    .setAuthor(message.guild.name, message.guild.iconURL({dynamic:true}))
        .addField("Üye Sayısı", message.guild.memberCount, true)
  .setFooter( `© ${client.user.username} 2021-2022`,
      client.user.displayAvatarURL({ dynamic: true })
    ));

}

exports.config = {
    name: "say",
    aliases: ["say"]
};