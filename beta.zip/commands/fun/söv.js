exports.run = async (client, msg, args) => {
  let kufur=["amınakoyum ne ayaksın gevşek, dissini dinle amınakoyum yarram gibi olmuş", ":d kes lan amınakoduğum oğlu lan amınakoydugumun ibnesi daha senin kayıt yerin yok lan hırrime gidirsen dinçer öztürkün götüne yapışirsen ki sene kayıt alsın", "ben sana daha diss atmıyorumsenin ta yetmişyedi sülanenin amınakoyum bin tane de diss atsan daha sana cevap vermiyorum amınakoyum", "bir daha urfalılara laf söylerseniz özellikle de senin o kardeşin varya ismi ömer olan ta onun amınakoyarım", "facede iki de bir demesin urfalılar isotçudur isotçuların böyle bir yarrağı var bak böyle sokarlar sana ha ayık ol tamam mı", "artı ben urfalı değilim moruk siverekliyim zazayım marda tonne defakardo eksemi hırreme daha dün boktunuz amınakoyum bugün koktunuz", "youtubeda erkeksiniz feyste erkeksiniz götün yerse urfaya gel", "bide disste diyorsun senin şehrinde bazı arkadaşlarım var seni arıyorlar beni aramasın yavrum", "beni vurmak için böyle bir daşşak lazım bide böyle bir göt lazım ki onları birbirine çakıştırıyim", "bizim burda ağacı kökten kralını götten sikerler olum ayık ol sen götün yerse mekanım urfa"]
     let member = msg.mentions.members.first()
   if(!member)return msg.channel.send({embed: {
 color:"#808080",
 description: (':no_entry_sign: Ya geçerli birini etiketle ya da sana sövmemi istiyosan kendini etiketle.')
}});
  if(member.id === "696407272145813505")return msg.channel.send({embed: {
 color: "808080",
 description: (':no_entry_sign: Sahibime sövme senin ölülerini diriltir siker siker çoğaltır öldürürüm, kodumun orospusu senin ananı götten babanı kökten sikerim orospu oç.')
}})
  if(member.id === "400618290650808320")return msg.channel.send({embed: {
 color: "808080",
 description: (`:no_entry_sign: Sahibime sövme senin ölülerini diriltir siker siker çoğaltır öldürürüm, kodumun orospusu senin ananı götten babanı kökten sikerim orospu oç.`)
}})
  if(member.id === client.user.id){
    msg.channel.send({embed: {
 color: "808080",
 description: (`:no_entry_sign: Beni mi kandırcan orospu çocuğu ?`)
}})
  }
  else{
  msg.channel.send({embed: {
 color: "808080",
 description: (`${member} ${kufur[Math.floor(Math.random() * 16)]}.`)
  }})
  }
  
}

exports.config = {
    name: "söv",
    aliases: ["küfür-et"]
};