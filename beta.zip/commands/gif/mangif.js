const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

let replies = ["https://cdn.discordapp.com/attachments/694693923486171177/737203415339499621/a_c3451f3e42065b560180028d3a62ef5a.gif","https://cdn.discordapp.com/attachments/694693923486171177/737219168822362183/a_9c8d6cb51559b033674ed8dd16234ee7.gif","https://cdn.discordapp.com/attachments/694693923486171177/737219065977765888/a_cb483fd9bfa2068e5b57aa6cf973986e.gif","https://cdn.discordapp.com/attachments/694693923486171177/737203076691394570/a_e8727598fec06c471cc305358b97596b.gif","https://cdn.discordapp.com/attachments/694693923486171177/737106443932532796/gif_200.gif","https://cdn.discordapp.com/attachments/694693923486171177/737106458080051330/gif_201.gif","https://cdn.discordapp.com/attachments/694693923486171177/737050698293968976/a_a873a018a2751ecaf654d116ae15c261.gif","https://cdn.discordapp.com/attachments/694693923486171177/737105973155463259/gif_180.gif","https://cdn.discordapp.com/attachments/694693923486171177/737106004977647726/gif_182.gif","https://cdn.discordapp.com/attachments/694693923486171177/737106176541589544/gif_187.gif","https://cdn.discordapp.com/attachments/694693923486171177/737106247643562004/gif_191.gif","https://cdn.discordapp.com/attachments/694693923486171177/737106368158367804/gif_196.gif","https://cdn.discordapp.com/attachments/694693923486171177/737013617538629722/a_fb64ba0c5d3b48b24d4334d7ac2b70af.gif","https://cdn.discordapp.com/attachments/694693923486171177/737013649058824252/a_ee0eab432a8d1eb6521c1a932dd04e22.gif","https://cdn.discordapp.com/attachments/694693923486171177/737038327672340541/a_2df0464c0f0e4dabf60385103b18addd.gif","https://cdn.discordapp.com/attachments/694693923486171177/737038499043213332/a_b4cad593a04df36fae504536a7971825.gif","https://cdn.discordapp.com/attachments/694693923486171177/737039041022787624/image0.gif","https://cdn.discordapp.com/attachments/694693923486171177/737039232065077269/image0-70.gif","https://cdn.discordapp.com/attachments/694693923486171177/737039292832153640/kaan.gif.gif","https://cdn.discordapp.com/attachments/694693923486171177/737203076691394570/a_e8727598fec06c471cc305358b97596b.gif","https://media.discordapp.net/attachments/694693923486171177/731076179972456498/a_079cdabfa553a52e258fe02dd0800452.gif?width=115&height=115","https://media.discordapp.net/attachments/631918688773079078/732031283949207556/a_371fb2987153b1a109547453e22d8f12.gif?width=115&height=115","https://media.discordapp.net/attachments/631918688773079078/731615763219349524/image0.gif?width=115&height=115","https://media.discordapp.net/attachments/694693923486171177/732205411662430269/e64884b0a9d7ddec3fd4cee9f7cf70fd.gif?width=220&height=220","https://media.discordapp.net/attachments/694693923486171177/730689384222949437/18-47-20-image4.gif?width=216&height=270","https://media.discordapp.net/attachments/694693923486171177/732216871402602517/Mulan_Gif_52-1.gif?width=115&height=115","https://cdn.discordapp.com/avatars/696407272145813505/a_e56eef65aec489743de2fb385a948382.gif","https://media.discordapp.net/attachments/694693923486171177/730687948185665586/a_0fa4f2789c6face5b8e298c9eb6f1e16.gif?width=115&height=115","https://images-ext-1.discordapp.net/external/lGmUBaskQxxDln1ykTYCp-yqzp8FWA0UjDnlCEPkutE/%3Fsize%3D2048/https/cdn.discordapp.com/avatars/696407272145813505/a_3823b23b1f7463bf74476bcb479e209b.gif?width=77&height=77"];

let result = Math.floor((Math.random() * replies.length));
  
let gifembed = new Discord.MessageEmbed()

.setTitle("Man Gif")

 .setColor("#808080")


.setImage(replies[result]);

message.channel.send(gifembed);

};
exports.config = {
  name: "man-gif",  //komutunuzun adı
  guildOnly: true, //burası kalsın
  aliases: [],  //komutu farklı isimde çalıştırmak için 
};