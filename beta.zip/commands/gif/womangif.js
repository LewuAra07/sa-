const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

let replies = ["https://cdn.discordapp.com/attachments/694694493525377035/737302021295833109/GIF-200727_113742.gif","https://cdn.discordapp.com/attachments/694694493525377035/737302739444301824/wqeqw.gif","https://cdn.discordapp.com/attachments/694694493525377035/737303378173886554/a_14254a7b0842b2a7f32a19cb34028da4.gif","https://cdn.discordapp.com/attachments/694694493525377035/737302765520551946/a_dfda87717edc3a1ee1057aec5304f082.gif","https://cdn.discordapp.com/attachments/694694493525377035/737310262906060810/image0.gif","https://cdn.discordapp.com/attachments/694694493525377035/737310178180989009/image0.gif","https://cdn.discordapp.com/attachments/694694493525377035/737310007929864252/image0.gif","https://cdn.discordapp.com/attachments/694694493525377035/737300958031380549/a_e052cc1eb09b212fa6b4c3644450b154.gif","https://cdn.discordapp.com/attachments/694694493525377035/737301552750002226/rosiegif4.gif","https://cdn.discordapp.com/attachments/694694493525377035/737301660455534642/GIF.6.gif","https://cdn.discordapp.com/attachments/694694493525377035/737301813912666145/gif_342.gif","https://cdn.discordapp.com/attachments/694694493525377035/737301817615974471/GIF.5.gif","https://cdn.discordapp.com/attachments/694694493525377035/737301870971846687/gif_346.gif","https://cdn.discordapp.com/attachments/694694493525377035/737301916379381790/gif_335.gif","https://cdn.discordapp.com/attachments/694694493525377035/737021018333249546/Lorie10.gif","https://cdn.discordapp.com/attachments/694694493525377035/737021142547693618/a_3a35e998e21a471ca9999b2e78051d53.gif","https://cdn.discordapp.com/attachments/694694493525377035/737036899612360774/a_0edcde786dca1aa7cb3caf12af732bc5.gif","https://media.discordapp.net/attachments/694694493525377035/732257676968460358/GIF-200615_010435.gif?width=270&height=270","https://media.discordapp.net/attachments/694694493525377035/732021042914000976/26.gif?width=115&height=115","https://media.discordapp.net/attachments/694694493525377035/732257455878176788/image0-3.gif?width=103&height=103","https://media.discordapp.net/attachments/694694493525377035/731789046443016252/image0-6.gif?width=115&height=115","https://media.discordapp.net/attachments/694694493525377035/732020730811777134/IMG_e047oi.gif?width=178&height=270","https://media.discordapp.net/attachments/694694493525377035/732232086865575996/a_20e51e044576c85f5ff7f4140a8fd1e8.gif?width=115&height=115","https://media.discordapp.net/attachments/694694493525377035/732257339440103505/a_ef00d827f2f76a6be5b0ed70bdd1618d.gif?width=115&height=115","https://media.discordapp.net/attachments/694694493525377035/732257456394076200/image0-2.gif?width=115&height=115"];

let result = Math.floor((Math.random() * replies.length));
  
let gifembed = new Discord.MessageEmbed()

.setTitle("Woman Gif")

 .setColor("#808080")
.setImage(replies[result]);

message.channel.send(gifembed);

};
exports.config = {
  name: "woman-gif",  //komutunuzun adı
  guildOnly: true, //burası kalsın
  aliases: ["woman"],  //komutu farklı isimde çalıştırmak için 
};