const Discord = require("discord.js");
const fs = require("fs");
const db = require("croxydb");
const client = new Discord.Client();
client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
require("./beta/dowlander.js")(client);
require('discord-buttons')(client);
require('discord-slider')(client);

client.on("ready", () => {
  console.log(
    `[BOT]: ${client.user.tag} ismiyle bağlandım!`
  );
  client.user.setPresence({
    activity: {
      name: `be✝a v1.0`,
      type: "WATCHING"
    },
    status: "idle"
  });
});


const { readdirSync } = require('fs')
readdirSync('./commands/').forEach(dir => {
  let files = readdirSync(`./commands/${dir}`)
  for (let file of files) {
    let cmd = require(`./commands/${dir}/${file}`);
    client.commands.set(cmd.config.name, cmd);
    cmd.config.aliases.forEach(alias => {
      client.aliases.set(alias, cmd.config.name);
    })
  }
})




client.login("").catch(error => { client.logger.error("token yanlış haci") })


client.on("ready", () => {
  client.channels.cache.get('SES KANAL ID').join();
});


client.on("guildMemberRemove", async member => {
  const channel = db.get(`sKanal_${member.guild.id}`);
  if (db.has(`sayac_${member.guild.id}`) == false) return;
  if (db.has(`sKanal_${member.guild.id}`) == false) return;

  member.guild.channels.cache
    .get(channel)
    .send(
      new Discord.MessageEmbed()
        .setColor("#808080")
        .setDescription(
          `:outbox_tray: **${member.user.tag }** Sunucudan ayrıldı, görüşmek üzere! \`${db.fetch(`sayac_${member.guild.id}` )}\` üye olmamıza son \`${db.fetch(`sayac_${member.guild.id}`) -
            member.guild.memberCount}\` üye kaldı!`)
      
    )
});

client.on("guildMemberAdd", async member => {
  const channel = db.get(`sKanal_${member.guild.id}`);
  if (db.has(`sayac_${member.guild.id}`) == false) return;
  if (db.has(`sKanal_${member.guild.id}`) == false) return;
  member.guild.channels.cache
    .get(channel)
    .send(new Discord.MessageEmbed()
          .setColor("#808080")
          .setDescription(
      `:inbox_tray: **${member.user.tag}** Sunucuya katıldı, hoş geldin! \`${db.fetch(
        `sayac_${member.guild.id}`
      )}\` üye olmamıza son \`${db.fetch(`sayac_${member.guild.id}`) -
        member.guild.memberCount}\` üye kaldı!` 
  ))
});



client.on('message', async message => {
if (message.content === '-fk') { // Buraya ne yazarsanız yazdığınız şeye göre çalışır
  client.emit('guildMemberAdd', message.member || await message.guild.fetchMember(message.author));
    }
});

